﻿#include <iostream>
#include <math.h>
#include <cmath>
#include <time.h>
#include <stdlib.h>
#include <windows.h>
#include <Glaux.h>
#include <glut.h>   //Подключение библиотеки glut.h


GLuint texture;



#define MAX_PARTICLES 1000
// угол поворота камеры
float angle = 0.0;
float rx = 1.0, ry = 1.0, rz = 1.0;
// координаты вектора направления движения камеры
float lx = 0.0f, lz = -1.0f;
// XZ позиция камеры
float x = 3.0f, z = 3.0f, dx = 0.01f, dz = 0.01f;
//Ключи статуса камеры. Переменные инициализируются нулевыми значениями
//когда клавиши не нажаты
float deltaAngle = 0.0f;
float deltaMove = 0;
int counter = 0;
GLfloat treecolor[] = { 0.9, 0.6, 0.3, 0.8 };
float pos0[] = { 0.0, 20.0, 1.0, 1.0 };
float pos1[] = { 20.0, 10.0, 30.0, 1.0 };
float direction[] = { 0.0, 0.0, -20.0 };
float diffuseColor1[] = { 1.0, 1.0, 1.0, 1.0 };
float ambientColor0[] = { 0.3, 0.3, 0.3, 1.0 };
float diffuseColor0[] = { 1.0, 1.0, 1.0, 1.0 };
// phisic
int V = 1;
float tm = 0;
float newX = 0;
float slowdown = 2.0;
float velocity = 0.0;
float zoom = -40.0;
int loop;
int fall;
//floor colors
float r = 0.0;
float gr = 1.0;
float b = 0.0;
float ground_points[21][21][3];
float ground_colors[21][21][4];
float accum = -10.0;
typedef struct {
	// Life
	bool alive;	// is the particle alive?
	float life;	// particle lifespan
	float fade; // decay
	// color
	float red;
	float green;
	float blue;
	// Position/direction
	float xpos;
	float ypos;
	float zpos;
	// Velocity/Direction, only goes down in y dir
	float vel;
	// Gravity
	float gravity;
}particles;
particles par_sys[MAX_PARTICLES];


void idle() {
	glutPostRedisplay();
}
void changeSize(int w, int h) {
	// предотвращение деления на ноль
	if (h == 0)
		h = 1;
	float ratio = w * 1.0 / h;
	// используем матрицу проекции
	glMatrixMode(GL_PROJECTION);
	// обнуляем матрицу
	glLoadIdentity();
	// установить параметры вьюпорта
	glViewport(0, 0, w, h);
	// установить корректную перспективу
	gluPerspective(45.0f, ratio, 0.1f, 100.0f);
	// вернуться к матрице проекции
	glMatrixMode(GL_MODELVIEW);
}
void initParticles(int i) {
	par_sys[i].alive = true;
	par_sys[i].life = 1.0;
	par_sys[i].fade = float(rand() % 100) / 1000.0f + 0.003f;

	par_sys[i].xpos = (float)(rand() % 21) - 10;
	par_sys[i].ypos = 10.0;
	par_sys[i].zpos = (float)(rand() % 21) - 10;

	par_sys[i].red = 0.5;
	par_sys[i].green = 0.5;
	par_sys[i].blue = 1.0;

	par_sys[i].vel = velocity;
	par_sys[i].gravity = -0.8;//-0.8;
}
void init() {
	

	glShadeModel(GL_SMOOTH);
	glClearColor(0.0, 0.0, 0.0, 0.0);
	glClearDepth(1.0);
	glEnable(GL_DEPTH_TEST);

	for (loop = 0; loop < MAX_PARTICLES; loop++) {
		initParticles(loop);
	}
}
// For Rain
void drawRain() {
	float x, y, z;
	for (loop = 0; loop < MAX_PARTICLES; loop = loop + 2) {
		if (par_sys[loop].alive == true) {
			x = par_sys[loop].xpos;
			y = par_sys[loop].ypos;
			z = par_sys[loop].zpos + zoom;

			// Draw particles
			glColor3f(0.5, 0.5, 1.0);
			glBegin(GL_LINES);
			glVertex3f(x, y, z);
			glVertex3f(x, y + 0.5, z);
			glEnd();
			// Update values
	  //Move
	  // Adjust slowdown for speed!
			par_sys[loop].ypos += par_sys[loop].vel / (slowdown * 1000);
			par_sys[loop].vel += par_sys[loop].gravity;
			// Decay
			par_sys[loop].life -= par_sys[loop].fade;

			if (par_sys[loop].ypos <= -10) {
				par_sys[loop].life = -1.0;
			}
			//Revive
			if (par_sys[loop].life < 0.0) {
				initParticles(loop);
			}
		}
	}
}



void drawHouse() {

	glColor3f(1.0, 0.0, 0.0);
	glTranslatef(10.0f, 0.5f, 0.0f);
	glutSolidCube(7.0);
	glColor3f(0.0, 0.0, 1.0);
	glutSolidCone(4.0, 4.0, 1.0, 1.0);
	glTranslatef(0.0f, 7.0f, 0.0f);
	glColor3f(0.0, 1.0, 0.0);
	glBegin(GL_TRIANGLES);

	glColor3f(0.0, 0.0, 1.0);// Сделали боковую сторону фиолетовой
	glVertex3f(3.5, -3.5, -3.5);
	glVertex3f(3.5, -3.5, 3.5);
	glVertex3f(0.0, 3.5, 0.0);
	glEnd();

	glBegin(GL_TRIANGLES);

	glColor3f(0.0, 0.0, 1.0);  // Сделали боковую сторону желтой
	glVertex3f(3.5, -3.5, 3.5);
	glVertex3f(-3.5, -3.5, 3.5);
	glVertex3f(0.0, 3.5, 0.0);
	glEnd();

	glBegin(GL_TRIANGLES);

	glColor3f(0.0, 0.0, 0.1);// Сделали сторону  розовой
	glVertex3f(-3.5, -3.5, 3.5);
	glVertex3f(-3.5, -3.5, -3.5);
	glVertex3f(0.0, 3.5, 0.0);
	glEnd();

	glBegin(GL_TRIANGLES);

	glColor3f(0.0, 0.0, 1.0);  // Сделали сторону  светло зеленой
	glVertex3f(-3.5, -3.5, -3.5);
	glVertex3f(3.5, -3.5, -3.5);
	glVertex3f(0.0, 3.5, 0.0);
	glEnd();

	glBegin(GL_QUADS);// основание пирамиды

	glColor3f(1.0, 0.0, 0.0); // сделали основание рыжим
	glVertex3f(3.5, -3.5, 3.5);
	glVertex3f(-3.5, -3.5, 3.5);
	glVertex3f(-3.5, -3.5, -3.5);
	glVertex3f(3.5, -3.5, -3.5);
	glEnd();

}

void computePos(float deltaMove)
{
	x += deltaMove * lx * 0.1f;
	z += deltaMove * lz * 0.1f;

}

void texture1() {
	AUX_RGBImageRec* texture1;
	texture1 = auxDIBImageLoad(L"les.bmp");
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glBindTexture(GL_TEXTURE_2D, texture);
	glTexImage2D(GL_TEXTURE_2D, 0, 3, texture1->sizeX, texture1->sizeY, 0, GL_RGB, GL_UNSIGNED_BYTE, texture1->data);
	glGenTextures(1, &texture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glBindTexture(GL_TEXTURE_2D, 0);
}


void drawTV() {
	glColor3f(0, 0, 0);
	glutSolidCube(0.5); //телек
	glPushMatrix();
	glTranslatef(0, 0, 0.07);
	glColor3f(0, 0, 2);	
	glutSolidCube(0.4); //экран
	glPopMatrix();
	glTranslatef(0, -0.5, 0);
	glColor3f(0.1f, 0.0f, 0.0f);
	glutSolidSphere(0.3, 50, 30); //подставка
	glTranslatef(0.2, 0.28, 0.26);
	glColor3f(1, 0, 0);
	glutSolidCube(0.05); //кнопка

}

void drawSofa() {
	glColor3f(0, 0, 1);
	glutSolidCube(1);
	glTranslatef(-0.5, 0.5, 0.5);

	glBegin(GL_QUADS);
	glColor3f(0, 0, 1); //zad
	glVertex3f(0, 0, 0);
	glVertex3f(1, 0, 0);
	glVertex3f(1, 0.5, 0);
	glVertex3f(0, 0.5, 0);

	glColor3f(0, 0, 1); //pered
	glVertex3f(0, 0, -0.2);
	glVertex3f(1, 0, -0.2);
	glVertex3f(1, 0.5, -0.2);
	glVertex3f(0, 0.5, -0.2);

	glColor3f(0, 0, 1); //leva
	glVertex3f(0, 0, 0);
	glVertex3f(0, 0, -0.2);
	glVertex3f(0, 0.5, -0.2);
	glVertex3f(0, 0.5, 0);

	glColor3f(0, 0, 1); //prava
	glVertex3f(1, 0, 0);
	glVertex3f(1, 0, -0.2);
	glVertex3f(1, 0.5, -0.2);
	glVertex3f(1, 0.5, 0);

	glColor3f(0, 0, 1); //verh
	glVertex3f(0, 0.5, 0);
	glVertex3f(1, 0.5, 0);
	glVertex3f(1, 0.5, -0.2);
	glVertex3f(0, 0.5, -0.2);

	glEnd();

	glBegin(GL_QUADS);//левая ручка
	glColor3f(0, 0, 1);
	glVertex3f(0, 0, 0);
	glVertex3f(0, 0, -1);
	glVertex3f(0, 0.5, -1);
	glVertex3f(0, 0.5, 0);

	glEnd();
	glPushMatrix();
	glTranslatef(0, -0.5, 0);
	glBegin(GL_QUADS);//левая ручка
	glColor3f(0, 0, 1);
	glVertex3f(-0.2, 0, 0);
	glVertex3f(-0.2, 0, -1);
	glVertex3f(-0.2, 1, -1);
	glVertex3f(-0.2, 1, 0);
	glEnd();
	glPopMatrix();

	glBegin(GL_QUADS);// левая ручка верх
	glColor3f(0, 0, 1);
	glVertex3f(-0.2, 0.5, -1);
	glVertex3f(-0.2, 0.5, 0);
	glVertex3f(0, 0.5, 0);
	glVertex3f(0, 0.5, -1);
	glEnd();

	glBegin(GL_QUADS);// левая ручка перед
	glColor3f(0, 0, 1);
	glVertex3f(-0.2, 0.5, -1);
	glVertex3f(-0.2, -0.5, -1);
	glVertex3f(0, -0.5, -1);
	glVertex3f(0, 0.5, -1);
	glEnd();


	glBegin(GL_QUADS);// правая ручка
	glColor3f(0, 0, 1);
	glVertex3f(1, 0, 0);
	glVertex3f(1, 0, -1);
	glVertex3f(1, 0.5, -1);
	glVertex3f(1, 0.5, 0);
	glEnd();

	glPushMatrix();
	glTranslatef(0, -0.5, 0);
	glBegin(GL_QUADS);// правая ручка
	glColor3f(0, 0, 1);
	glVertex3f(1.2, 0, 0);
	glVertex3f(1.2, 0, -1);
	glVertex3f(1.2, 1, -1);
	glVertex3f(1.2, 1, 0);
	glEnd();
	glPopMatrix();

	glBegin(GL_QUADS);// правая ручка верх
	glColor3f(0, 0, 1);
	glVertex3f(1.2, 0.5, -1);
	glVertex3f(1.2, 0.5, 0);
	glVertex3f(1, 0.5, 0);
	glVertex3f(1, 0.5, -1);
	glEnd();

	glBegin(GL_QUADS);// правая ручка перед
	glColor3f(0, 0, 1);
	glVertex3f(1.2, 0.5, -1);
	glVertex3f(1.2, -0.5, -1);
	glVertex3f(1, -0.5, -1);
	glVertex3f(1, 0.5, -1);
	glEnd();
}


void drawTable() {

	glColor3f(0.3, 0, 0);
	glTranslatef(-1, 0, -0.5);
	glutSolidCube(0.6);

	glColor3f(0.2, 0.0, 0.0);
	glTranslatef(0, 0, -0.1);
	glutSolidCube(0.5);
	glTranslatef(-0.15, 0, -0.2);
	glColor3f(0, 0, 0);
	glutSolidSphere(0.1, 30, 30);
}

void drawDoor() { 

	
	glBegin(GL_QUADS);
	glColor3f(0, 0, 1);
	glVertex3f(0, -1, -3.9);
	glVertex3f(0, 2, -3.9);
	glVertex3f(1, 2, -3.9);
	glVertex3f(1, -1, -3.9);
	glEnd();

	glBegin(GL_QUADS);
	glColor3f(0, 0, 1);
	glVertex3f(0, -1, -3.75);
	glVertex3f(0, 2, -3.75);
	glVertex3f(1, 2, -3.75);
	glVertex3f(1, -1, -3.75);
	glEnd();

	glBegin(GL_QUADS);
	glColor3f(0, 0, 1);
	glVertex3f(0, -1, -3.9);
	glVertex3f(0, 2, -3.9);
	glVertex3f(0, 2, -3.75);
	glVertex3f(0, -1, -3.75);
	glEnd();

	glBegin(GL_QUADS);
	glColor3f(0, 0, 1);
	glVertex3f(1, -1, -3.9);
	glVertex3f(1, 2, -3.9);
	glVertex3f(1, 2, -3.75);
	glVertex3f(1, -1, -3.75);
	glEnd();

	glPushMatrix();
	glTranslatef(0.05, 0.5, -3.9);
	glutSolidSphere(0.05, 30, 30);
	glPopMatrix();
	glPushMatrix();
	glTranslatef(0.05, 0.5, -3.75);
	glutSolidSphere(0.05, 30, 30);
	glPopMatrix();
}



void drawClouds() {
		glColor3f(1.0, 1.0, 1.0);
		glutSolidSphere(1.5, 30, 30);
}
void computeDir(float deltaAngle)
{
	angle += deltaAngle;
	lx = sin(angle);
	lz = -cos(angle);
}




















void renderScene(void) {

	for (int i = -1; i < 3; ++i) {
		for (int j = -1; j < 4; ++j) {
			glPushMatrix();
			glTranslatef(i * 9.0, 0, j * 9.0);
			drawHouse();
			glTranslatef(0, -7, 0);
			drawTV();	
			drawDoor();
			glTranslatef(0, -0.5, 2.73);
			drawSofa();
			glPushMatrix();
			drawTable();		
			glPopMatrix();
			glPopMatrix();
			
		}
	}
	for (int i = -2; i < 7; i++) {
		for (int j = -2; j < 7; j++) {
			glPushMatrix();
			glTranslatef(i * 2, 15, j * 2);
			drawClouds();
			glPopMatrix();
		}
	}
	glTranslatef(0, 0, -30);
	for (int i = -2; i < 5; i++) {
		for (int j = -2; j < 5; j++) {
			glPushMatrix();
			glTranslatef(i * 2, 17, j * 2);
			drawClouds();
			glPopMatrix();
		}
	}


	glFlush();
	glutSwapBuffers();
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuseColor0);
	glLightfv(GL_LIGHT0, GL_AMBIENT, ambientColor0);
	glLightfv(GL_LIGHT0, GL_POSITION, pos0);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, diffuseColor1);
	glLightfv(GL_LIGHT1, GL_POSITION, pos1);
	glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, direction);
	glLightf(GL_LIGHT1, GL_SPOT_CUTOFF, 15.0);
	glLightf(GL_LIGHT1, GL_SPOT_EXPONENT, 120);
	glPushMatrix();
	glPopMatrix();

	if (deltaMove)
		computePos(deltaMove);
	if (deltaAngle)
		computeDir(deltaAngle);
	//очистить буфер цвета и глубины
	// обнулить трансформацию
	glLoadIdentity();
	glColor3f(0.0, 0.0, 0.0);
	glBegin(GL_LINES);
	glVertex3f(-0.05, 0.0, -1.0);
	glVertex3f(0.05, 0.0, -1.0);
	glVertex3f(0.0, -0.05, -1.0);
	glVertex3f(0.0, 0.05, -1.0);
	glEnd();
	// установить камеру
	gluLookAt(x, 1.0f, z,
		x - lx, 1.0f, z - lz,
		0.0f, 1.0f, 0.0f);


	glBegin(GL_QUADS);// полигон с коондинатами //пол
	
	glColor3f(0.5f, 0.5f, 0.5f);
	glVertex3f(-40.0f, 0.0f, -40.0f);
	glColor3f(0.5f, 0.5f, 0.5f);
	glVertex3f(-40.0f, 0.0f, 40.0f);
	glColor3f(0.5f, 0.5f, 0.5f);
	glVertex3f(40.0f, 0.0f, 40.0f);
	glColor3f(0.5f, 0.5f, 0.5f);
	glVertex3f(40.0f, 0.0f, -40.0f);
	glEnd();









	

	glBegin(GL_QUADS);
	glBindTexture(GL_TEXTURE_2D, texture);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-40.0f, 0.0f, -40.0f);
	glTexCoord2f(0.0f, 1.0f); 
	glVertex3f(-40.0f, 20.0f, -40.0f);
	glTexCoord2f(1.0f, 1.0f); 
	glVertex3f(40.0f, 20.0f, -40.0f);
	glTexCoord2f(1.0f, 0.0f); 
	glVertex3f(40.0f, 0.0f, -40.0f);
	glEnd();
	glBindTexture(GL_TEXTURE_2D, 0);


	glBegin(GL_QUADS);// полигон с коондинатами
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(40.0f, 0.0f, -40.0f);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(40.0f, 20.0f, -40.0f);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(40.0f, 20.0f, 40.0f);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(40.0f, 0.0f, 40.0f);
	glEnd();

	glBegin(GL_QUADS);// полигон с коондинатами
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-40.0f, 0.0f, -40.0f);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(-40.0f, 20.0f, -40.0f);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(-40.0f, 20.0f, 40.0f);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(-40.0f, 0.0f, 40.0f);
	glEnd();

	glBegin(GL_QUADS);// полигон с коондинатами
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-40.0f, 0.0f, 40.0f);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(-40.0f, 20.0f, 40.0f);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(40.0f, 20.0f, 40.0f);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(40.0f, 0.0f, 40.0f);
	glEnd();


















	glBegin(GL_QUADS);// полигон с коондинатами
	glColor3f(0.0f, 0.0f, 0.0f);
	glVertex3f(-40.0f, 20.0f, -40.0f);
	glColor3f(0.0f, 0.0f, 0.0f);
	glVertex3f(40.0f, 20.0f, -40.0f);
	glColor3f(0.0f, 0.0f, 0.0f);
	glVertex3f(40.0f, 20.0f, 40.0f);
	glColor3f(0.0f, 0.0f, 0.0f);
	glVertex3f(-40.0f, 20.0f, 40.0f);
	glEnd();



	glPushMatrix();
	glTranslatef(10, 10, 13);
	drawRain();
	glPopMatrix();
	glPushMatrix();
	glTranslatef(0, 10, 0);
	for (int i = -3; i < 4; i++) {
		for (int j = 0; j < 3; j++) {
			glPushMatrix();
			glTranslatef(8 * i, 0, 7 * j);
			drawRain();
			glPopMatrix();	
		}
	}
	for (int k = 0; k < 10; k++)
	{
		glPushMatrix();
		glTranslatef(-15, 0, 8 * k);
		drawRain();
		glPopMatrix();
	}
	for (int k = 0; k < 10; k++)
	{
		glPushMatrix();
		glTranslatef(-30, 0, 8 * k);
		drawRain();
		glPopMatrix();
	}
	glPopMatrix();
	glPopMatrix();
}


void pressKey(int key, int xx, int yy) {

	switch (key) {
	case GLUT_KEY_LEFT:
		deltaAngle = -0.05f;
		break;
	case GLUT_KEY_RIGHT:
		deltaAngle = 0.05f;
		break;
	case GLUT_KEY_UP:
		deltaMove = -1.0f;
		break;
	case GLUT_KEY_DOWN:
		deltaMove = 1.0f;
		break;
	case GLUT_KEY_INSERT:
		exit(1);
		break;
	}
}
void timerF(int = 0) {
	renderScene();
	glutTimerFunc(1, timerF, 0);

}

void releaseKey(int key, int x, int y) {

	switch (key) {
	case GLUT_KEY_LEFT:
	case GLUT_KEY_RIGHT:
		deltaAngle = 0.0f;
		break;
	case GLUT_KEY_UP:
	case GLUT_KEY_DOWN:
		deltaMove = 0;
		break;


	}
}




int main(int argc, char** argv) {



	// инициализация GLUT и создание окна
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_RGBA);
	glutInitWindowPosition(100, 100);
	glutInitWindowSize(1280, 720);
	glutCreateWindow("Project");
	glClearColor(0.1, 0.1, 0.15, 0.0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-500, 500, -500, 500, -500, 500);
	// регистрация вызовов
	glutDisplayFunc(renderScene);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
	glEnable(GL_COLOR_MATERIAL);
	glEnable(GL_TEXTURE_2D);
	glColor3f(1.0, 0.0, 0.0);
	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHT1);
	init();
	glutIdleFunc(idle);
	texture1();
	glutReshapeFunc(changeSize);
	glutIdleFunc(renderScene);
	glutSpecialFunc(pressKey);
	glutTimerFunc(30, timerF, 0);

	// Новые функции для регистрации
	glutIgnoreKeyRepeat(1);
	glutSpecialUpFunc(releaseKey);
	// OpenGL - инициализация функции теста
	glEnable(GL_DEPTH_TEST);
	// главный цикл

	glutMainLoop();

	return 1;
}